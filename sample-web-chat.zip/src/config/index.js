import { NMConfig, BGConfig, HConfig } from './sample';

export const Config = {
  'Sample': NMConfig,
  'Bergdorf Goodman': BGConfig,
  'Horchow': HConfig
};
