export default theme => ({
  twcAttachmentPickerInput: {
    display: 'none !important'
  }
});