import React, { Component, useRef } from 'react';
import { Grid, withStyles } from '@material-ui/core';
import styles from './styles';
import { FileHelpers } from '../../utils/helpers';
import AvatarIcon from '../../assets/AvatarIcon';

class AvatarGroup extends Component {
    constructor(props) {
        super(props);
        this.state = { avatarList: [] };
    }

    componentDidMount() {
        const styleAvatarsList = FileHelpers.getRandomAvatars('Style');
        this.setState({ avatarList: styleAvatarsList })
    }

    render() {
        const { avatarList } = this.state;
        return (
            <React.Fragment >
                <Grid container direction="column" alignItems="center" justifyContent="center">
                    <Grid item xs={12}>
                        <div style={{ display: 'flex' }}>
                            <AvatarIcon agentImageFileName={avatarList[0]} formType={'Style'} />
                            <AvatarIcon agentImageFileName={avatarList[1]} formType={'Style'} />
                            <AvatarIcon agentImageFileName={avatarList[2]} formType={'Style'} />
                        </div>
                    </Grid>
                </Grid>
            </React.Fragment>
        );
    }
}


export default withStyles(styles)(AvatarGroup);