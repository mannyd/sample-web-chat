export default theme => ({
  twcAvatarGroupsAvatarClass: {
    // width: 45,
    // height: 45
  },
  twcAvatarGroupsChatHeader: { 
    padding: 10,
    fontSize: 18,
    fontWeight: 400 
  }
});