import React from 'react';
import { Avatar } from '@material-ui/core';

const { CLOUDINARY_URL } = require('../utils/constants');

const replaceImage = (error) => {
  console.log('onerror');
  //replacement of broken Image
  error.target.src = `${CLOUDINARY_URL}avatar.png`;;
}

const AvatarIcon = props => {
  let { width, height, agentImageFileName, formType, convStatus } = props;

  let avatar = `${CLOUDINARY_URL}avatar.png`;

  // checking if agent image exists, if not set image to default avatar image
  if (agentImageFileName !== undefined && agentImageFileName !== '') {
    try {
      if (formType === 'Style' && convStatus === undefined) {
        avatar = `${CLOUDINARY_URL}${agentImageFileName}`;
      }
      else if (formType === 'Beauty' && convStatus === undefined) {
        avatar = `${CLOUDINARY_URL}${agentImageFileName}`;
      }
      else {
        avatar = agentImageFileName;

      }
    } catch (error) {
      avatar = `${CLOUDINARY_URL}avatar.png`;
    }
  }
  if (width == undefined) {
    width = "30px";
  }
  if (height == undefined) {
    height = "30px";
  }

  const classes = {
    avatar: {
      width: width,
      height: height
    }
  }

  return (
    <>
      <Avatar key={'avatar-1'} alt={'avatar'}
        src={avatar}
        onError={replaceImage}
      />
    </>
  );
};

export default AvatarIcon;