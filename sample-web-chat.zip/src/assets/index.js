import AttachIcon from './AttachIcon';
import EmojiIcon from './EmojiIcon';
import SendIcon from './SendIcon';

export default {
  AttachIcon,
  EmojiIcon,
  SendIcon
};
